
#include "RDKESP8266.h"

// Constructor
RDKESP8266::RDKESP8266(Stream *s, Stream *d, int8_t r) :
stream(s), debug(d), reset_pin(r), host(NULL), writing(false) {
	setTimeouts();
};

void RDKESP8266::setTimeouts( uint32_t rcv, uint32_t rst, uint32_t con) {
	if(rcv) 	receiveTimeout = rcv;
	if(rst) resetTimeout   = rst;
	if(con) connectTimeout = con;
}

size_t RDKESP8266::write(uint8_t c) {
	if(debug) {
		if(!writing) {
			debug->print(F("---> "));
			writing = true;
		}
		debug->write(c);
	}
	return stream->write(c);
}

boolean RDKESP8266::find(Fstr *str) {

	uint8_t  stringLength, matchedLength = 0;
	int      c;
	boolean  found = false;
	uint32_t t;
	uint16_t bytesToGo = 0;

	if(str == NULL) str = F("OK\r\n"); //
	stringLength = strlen_P((Pchr *)str);

	if(debug && writing) {
		debug->print(F("<--- "));
		writing = false;
	}

	t=millis();
	while(true){
		c = stream->read();
		if(c > 0) {
			if(debug) debug->write(c);
			bytesToGo--;
			if(c == pgm_read_byte((Pchr *)str + matchedLength)) {
				if(++matchedLength == stringLength) {
					found = true;
					goto bail;
				}
			} else {
				matchedLength = 0;
			}
			t = millis();
		} else {  // No data on stream, check for timeout
			if((millis() - t) > receiveTimeout) {
				goto bail; // You lose, good day sir
			}
		}
	}

	bail:
	while (stream->available()){
		stream->flush();
	}
	debug->println();
	return found;
}

int RDKESP8266::readLine(char *buf, int bufSiz) {
	if(debug && writing) {
		debug->print(F("<--- "));
		writing = false;
	}
	int bytesRead = stream->readBytesUntil('\r', buf, bufSiz-1);
	buf[bytesRead] = 0;

	while(stream->read() != '\n');
	return bytesRead;
}

boolean RDKESP8266::hardReset(void) {
	if(reset_pin < 0) return true;
	boolean found = false;
	int i = 0;
	uint32_t save  = receiveTimeout; // Temporarily override receive timeout,
	setTimeouts(resetTimeout);   // reset time is longer than normal I/O.
	// Wait for boot message

	while(i<5 && !found){
		debug->print(F("Hard reset, attempt "));
		debug->println(i+1);
		digitalWrite(reset_pin, LOW);
		pinMode(reset_pin, OUTPUT);
		delay(100);
		pinMode(reset_pin, INPUT);
		delay(50);
		found = find(F("ready")); // OK?
		i++;
	}
	setTimeouts(save);           // Restore normal receive timeout
	return found;
}

boolean RDKESP8266::deepSleep(uint16_t time) {
	print(F("AT+GSLP="));
	println(time);
	debug->println(F("Asleep"));
	return true;
}

boolean RDKESP8266::softReset(void) {
	boolean  found = false;
	uint32_t save  = receiveTimeout; // Temporarily override receive timeout,
	setTimeouts(resetTimeout);   // reset time is longer than normal I/O.
	println(F("AT+RST"));            // Issue soft-reset command
	if(find()) {           // Wait for boot message
		println(F("AT"));            // Turn off echo
		found = find();
		println(F("ATE0"));            // Turn off echo
		found = find();                // OK?
	}
	setTimeouts(save);           // Restore normal receive timeout
	return found;
}

void RDKESP8266::debugLoop(void) {
	if(!debug) for(;;);

	debug->println(F("\n========================"));
	for(;;) {
		if(debug->available())  stream->write(debug->read());
		if(stream->available()) debug->write(stream->read());
	}
}

boolean RDKESP8266::connectToAP(char *ssid, char *pass) {
	char buf[256];
	readLine(buf, sizeof(buf));
	println(F("AT+CWMODE=1")); // WiFi mode = Sta
	if(!find()) return false;
	print(F("AT+CWJAP=\""));
	print(ssid);
	print(F("\",\""));
	print(pass);
	println('\"');
	uint32_t save = receiveTimeout;
	setTimeouts(connectTimeout);
	boolean found = find();
	setTimeouts(save);
	if(found) {
		println(F("AT+CIPMUX=0"));
		found = find();
	}
	return found;
}

void RDKESP8266::closeAP(void) {
	println(F("AT+CWQAP"));
	find();
}

boolean RDKESP8266::setServerMode(byte mode) {
	if (mode==0) {
		println(F("AT+CIPSERVER=0"));
	} else {
		println(F("AT+CIPSERVER=1"));
	}
	if(find()) {
		return true;
	}
	return false;
}

boolean RDKESP8266::setMultiConnect(byte mode) {
	if (mode==0) {
		println(F("AT+CIPMUX=0"));
	} else {
		println(F("AT+CIPMUX=1"));
	}
	if(find()) {
		return true;
	}
	return false;
}

boolean RDKESP8266::connectTCP(Fstr *h, int port) {
	print(F("AT+CIPSTART=\"TCP\",\""));
	print(h);
	print(F("\","));
	println(port);
	uint32_t save = receiveTimeout;
	setTimeouts(connectTimeout);
	boolean found = find();
	setTimeouts(save);

	if(found) {
		host = h;
		return true;
	}
	return false;
}

boolean RDKESP8266::sendTCP(uint16_t length) {
	print(F("AT+CIPSEND="));
	println(length);
	if(find()) {
		return true;
	}
	return false;
}

boolean RDKESP8266::checkIP(void) {
	println(F("AT+CIFSR"));
	return find();
}

void RDKESP8266::closeTCP(void) {
	println(F("AT+CIPCLOSE"));
	find(F("Unlink\r\n"));
}

boolean RDKESP8266::requestURL(Fstr *url) {
	print(F("AT+CIPSEND="));
	println(25 + strlen_P((Pchr *)url) + strlen_P((Pchr *)host));
	if(find(F("> "))) {
		print(F("GET "));
		print(url);
		print(F(" HTTP/1.1\r\nHost: "));
		print(host);
		print(F("\r\n\r\n")); // 4
		return(find());
	}
	return false;
}

boolean RDKESP8266::requestURL(char* url) {
	print(F("AT+CIPSEND="));
	println(25 + strlen(url) + strlen_P((Pchr *)host));
	if(find(F("> "))) {
		print(F("GET "));
		print(url);
		print(F(" HTTP/1.1\r\nHost: "));
		print(host);
		print(F("\r\n\r\n")); // 4
		return(find());
	}
	return false;
}
