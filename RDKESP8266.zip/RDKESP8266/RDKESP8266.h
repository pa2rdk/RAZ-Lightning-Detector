
#ifndef _RDKESP8266_H_
#define _RDKESP8266_H_

#include <Arduino.h>

#define ESP_RECEIVE_TIMEOUT   1000L
#define ESP_RESET_TIMEOUT     5000L
#define ESP_CONNECT_TIMEOUT  15000L
#define ESP_IPD_TIMEOUT     120000L

typedef const __FlashStringHelper Fstr; 
typedef const PROGMEM char        Pchr; 

#define defaultBootMarker F("ready\r\n")

class RDKESP8266 : public Print {
 public:
  RDKESP8266(Stream *s = &Serial, Stream *d = NULL, int8_t r = -1);
  boolean   hardReset(void),
            softReset(void),
			checkIP(void),
            find(Fstr *str = NULL),
            connectToAP(char *ssid, char *pass),
            connectTCP(Fstr *host, int port),
            requestURL(Fstr *url),
            requestURL(char* url),
            setServerMode(byte mode),
            setMultiConnect(byte mode),
            sendTCP(uint16_t length),
			deepSleep(uint16_t time);
  int       readLine(char *buf, int bufSiz);
  void      closeAP(void),
            closeTCP(void),
            debugLoop(void),
            setDebug(Stream *d = NULL),
            setTimeouts(uint32_t rcv = ESP_RECEIVE_TIMEOUT,
                        uint32_t rst = ESP_RESET_TIMEOUT,
                        uint32_t con = ESP_CONNECT_TIMEOUT);
 private:
  Stream   *stream,     
           *debug;     
  uint32_t  receiveTimeout, resetTimeout, connectTimeout, ipdTimeout;
  int8_t    reset_pin;  // -1 if RST not connected
  Fstr     *host;
  boolean   writing;
  virtual size_t write(uint8_t); 
};

#endif // _RDKESP8266_H_
